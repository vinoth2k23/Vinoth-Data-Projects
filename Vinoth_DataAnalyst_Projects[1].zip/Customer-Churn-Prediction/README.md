# Customer Churn Prediction
Used logistic regression to predict whether a customer will leave the service based on usage, payment, and tenure data.

## Steps:
- Cleaned and analyzed data
- Feature engineered categorical variables
- Trained and evaluated logistic regression model
