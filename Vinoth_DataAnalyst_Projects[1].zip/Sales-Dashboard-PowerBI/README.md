# Sales Dashboard (Power BI)
Created an interactive dashboard to track KPIs, regional sales, category-wise profits, and trends using slicers and filters.

## Features:
- Total Sales, Profit, Quantity KPIs
- Trend line by month
- Region-wise and Segment-wise breakdown
