# Twitter Sentiment Analysis App
Lexicon-based sentiment analyzer using a GUI interface. Visualizes emotion distribution of tweet text input by user.

## Tools:
- Tkinter (GUI)
- Matplotlib (Bar chart)
- emotion.csv lexicon for emotion mapping
