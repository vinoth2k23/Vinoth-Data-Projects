import tkinter as tk
from tkinter import messagebox
import matplotlib.pyplot as plt

def analyze_sentiment(text):
    # Dummy sentiment logic
    emotions = {'happy': 2, 'sad': 1}
    plt.bar(emotions.keys(), emotions.values())
    plt.title("Emotion Distribution")
    plt.show()

root = tk.Tk()
root.title("Twitter Sentiment Analysis")
tk.Label(root, text="Enter Tweet:").pack()
entry = tk.Entry(root, width=50)
entry.pack()
tk.Button(root, text="Analyze", command=lambda: analyze_sentiment(entry.get())).pack()
root.mainloop()
